package br.com.pedroxsqueiroz.bt_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtApiApplication.class, args);
	}

}
