package br.com.pedroxsqueiroz.bt_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
